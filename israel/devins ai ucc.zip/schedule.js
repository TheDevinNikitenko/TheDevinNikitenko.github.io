const schedule = {
    "Mainstage": [
        { name: "SAM FELDT", start: "16:00", end: "16:50" },
        { name: "TIMMY TRUMPET", start: "16:50", end: "17:55" },
        { name: "SUBTRONICS", start: "17:55", end: "19:00" },
        { name: "TIESTO", start: "19:00", end: "20:20" },
        { name: "AFROJACK", start: "20:20", end: "21:25" },
        { name: "ALESSO", start: "21:25", end: "22:30" },
        { name: "EVERYTHING ALWAYS (DOM DOLLA + JOHN SUMMIT)", start: "22:30", end: "23:59" }
    ],
    "Worldwide": [
        { name: "SCHROTHAGEN", start: "16:00", end: "17:00" },
        { name: "RUBEN DE RONDE", start: "17:00", end: "18:00" },
        { name: "NIFRA", start: "18:00", end: "19:00" },
        { name: "MADDIX", start: "19:00", end: "20:15" },
        { name: "OLIVER HELDENS", start: "20:15", end: "21:30" },
        { name: "ARMIN VAN BUUREN", start: "21:30", end: "23:00" },
        { name: "ARMIN VAN BUUREN B2B MADDIX B2B OLIVER HELDENS", start: "23:00", end: "23:59" }
    ],
    "Megastructure": [
        { name: "MARCO FARAONE B2B MAR-T", start: "16:00", end: "17:30" },
        { name: "MISS MONIQUE", start: "17:30", end: "19:00" },
        { name: "ARTBAT", start: "19:00", end: "20:30" },
        { name: "BORIS BREJCHA", start: "20:30", end: "22:00" },
        { name: "CHARLOTTE DE WITTE", start: "22:00", end: "23:59" }
    ],
    "Cove": [
        { name: "JOYHAUSER", start: "16:00", end: "17:30" },
        { name: "JOSH WINK", start: "17:30", end: "19:00" },
        { name: "NIC FANCIULLI", start: "19:00", end: "20:30" },
        { name: "PATRICK TOPPING", start: "20:30", end: "22:00" },
        { name: "ELI BROWN", start: "22:00", end: "23:59" }
    ],
    "Live Stage": [
        { name: "SKEPSIS", start: "16:00", end: "17:25" },
        { name: "VENBEE", start: "17:25", end: "18:40" },
        { name: "NERO", start: "18:40", end: "19:50" },
        { name: "CHASE AND STATUS", start: "19:50", end: "21:40" },
        { name: "PENDULUM LIVE", start: "21:40", end: "23:00" },
        { name: "ZEDS DEAD", start: "23:00", end: "23:59" }
    ]
};

// Store countdown intervals for cleanup
const countdownIntervals = {};

function updateTime() {
    const now = new Date();
    const options = { 
        timeZone: 'America/New_York',
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false
    };
    const timeElement = document.getElementById('current-time');
    if (timeElement) {
        timeElement.textContent = 
            `EST ${now.toLocaleTimeString('en-US', options)} · ${now.toLocaleDateString('en-US', { 
                timeZone: 'America/New_York',
                weekday: 'short', 
                month: 'short', 
                day: 'numeric' 
            })}`;
    }
}

function transferHighlight(stageName, currentArtistEl, nextArtistEl) {
    // Clear existing countdown for current artist
    if (countdownIntervals[currentArtistEl.id]) {
        clearInterval(countdownIntervals[currentArtistEl.id]);
        delete countdownIntervals[currentArtistEl.id];
    }

    // Add transfer animation to stage
    const stageEl = currentArtistEl.closest('.stage');
    stageEl.classList.add('stage-change');
    setTimeout(() => stageEl.classList.remove('stage-change'), 1000);
    
    // Add transfer animation to artists
    currentArtistEl.classList.add('highlight-transfer');
    nextArtistEl.classList.add('highlight-transfer');
    
    // Remove animations after they complete
    setTimeout(() => {
        currentArtistEl.classList.remove('highlight-transfer');
        nextArtistEl.classList.remove('highlight-transfer');
    }, 800);
    
    // Update classes
    currentArtistEl.classList.remove('current-artist');
    currentArtistEl.querySelector('.countdown')?.remove();
    
    nextArtistEl.classList.add('current-artist');
    
    // Create and start countdown for new current artist
    const endTime = nextArtistEl.querySelector('.artist-time').textContent.split(' - ')[1];
    const countdownEl = document.createElement('div');
    countdownEl.className = 'countdown';
    nextArtistEl.appendChild(countdownEl);
    startCountdown(nextArtistEl, endTime);
}

function checkForSetChanges() {
    const now = new Date();
    const estTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    const currentHours = estTime.getHours();
    const currentMinutes = estTime.getMinutes();
    const currentTime = currentHours * 60 + currentMinutes;
    
    document.querySelectorAll('.stage').forEach(stageEl => {
        const stageName = stageEl.querySelector('.stage-name').textContent;
        const artists = schedule[stageName];
        const artistEls = stageEl.querySelectorAll('.artist');
        
        artists.forEach((artist, index) => {
            const [startH, startM] = artist.start.split(':').map(Number);
            const [endH, endM] = artist.end.split(':').map(Number);
            const startTime = startH * 60 + startM;
            const endTime = endH * 60 + endM;
            
            const artistEl = artistEls[index];
            const isCurrent = currentTime >= startTime && currentTime < endTime;
            
            // Check if this artist just became current
            if (isCurrent && !artistEl.classList.contains('current-artist')) {
                const currentArtistEl = stageEl.querySelector('.current-artist');
                if (currentArtistEl) {
                    transferHighlight(stageName, currentArtistEl, artistEl);
                } else {
                    // First artist of the day
                    artistEl.classList.add('current-artist');
                    const countdownEl = document.createElement('div');
                    countdownEl.className = 'countdown';
                    artistEl.appendChild(countdownEl);
                    startCountdown(artistEl, artist.end);
                }
            }
        });
    });
}

function startCountdown(artistEl, endTime) {
    // Clear any existing interval for this artist
    if (countdownIntervals[artistEl.id]) {
        clearInterval(countdownIntervals[artistEl.id]);
        delete countdownIntervals[artistEl.id];
    }

    function update() {
        const now = new Date();
        const estNow = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
        const [endH, endM] = endTime.split(':').map(Number);
        const endDate = new Date(estNow);
        endDate.setHours(endH, endM, 0, 0);

        if (endDate < estNow) {
            endDate.setDate(endDate.getDate() + 1);
        }

        const diff = endDate - estNow;
        
        if (diff <= 0) {
            const countdownEl = artistEl.querySelector('.countdown');
            if (countdownEl) {
                countdownEl.textContent = "ENDING";
            }
            checkForSetChanges(); // Trigger highlight transfer
            return;
        }

        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);

        const countdownEl = artistEl.querySelector('.countdown');
        if (countdownEl) {
            countdownEl.textContent = 
                `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
    }

    update();
    countdownIntervals[artistEl.id] = setInterval(update, 1000);
}

// Initialize with faster check interval
document.addEventListener('DOMContentLoaded', () => {
    updateTime();
    renderSchedule();
    setInterval(updateTime, 1000);
    setInterval(checkForSetChanges, 1000);
});
function renderSchedule() {
    const now = new Date();
    const estTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    const currentHours = estTime.getHours();
    const currentMinutes = estTime.getMinutes();
    const currentTime = currentHours * 60 + currentMinutes;
    
    const container = document.getElementById('stages-container');
    if (!container) {
        console.error("Could not find stages container element");
        return;
    }
    
    // Clear existing countdown intervals
    Object.values(countdownIntervals).forEach(interval => clearInterval(interval));
    container.innerHTML = '';
    
    for (const [stageName, artists] of Object.entries(schedule)) {
        const stageEl = document.createElement('div');
        stageEl.className = 'stage';
        
        const stageHeader = document.createElement('div');
        stageHeader.className = 'stage-header';
        
        const stageNameEl = document.createElement('h2');
        stageNameEl.className = 'stage-name';
        stageNameEl.textContent = stageName;
        stageHeader.appendChild(stageNameEl);
        
        stageEl.appendChild(stageHeader);
        
        const artistList = document.createElement('ul');
        artistList.className = 'artist-list';
        
        artists.forEach((artist, index) => {
            const [startH, startM] = artist.start.split(':').map(Number);
            const [endH, endM] = artist.end.split(':').map(Number);
            const startTime = startH * 60 + startM;
            const endTime = endH * 60 + endM;
            
            const isCurrent = currentTime >= startTime && currentTime < endTime;
            const isNext = index > 0 ? (currentTime >= artists[index-1].end.split(':').map(Number).reduce((h, m) => h * 60 + m) && 
                                      currentTime < startTime) : currentTime < startTime;
            
            const artistEl = document.createElement('li');
            artistEl.className = `artist ${isCurrent ? 'current-artist' : ''}`;
            artistEl.id = `${stageName.replace(/\s+/g, '-')}-${artist.name.replace(/\s+/g, '-')}`;
            
            const artistInfo = document.createElement('div');
            artistInfo.className = 'artist-info';
            
            const nameSpan = document.createElement('span');
            nameSpan.className = 'artist-name';
            nameSpan.textContent = artist.name;
            
            const timeSpan = document.createElement('span');
            timeSpan.className = 'artist-time';
            timeSpan.textContent = `${artist.start} - ${artist.end}`;
            
            artistInfo.appendChild(nameSpan);
            artistInfo.appendChild(timeSpan);
            
            artistEl.appendChild(artistInfo);
            
            // Add countdown for current and next artists
            if (isCurrent) {
                const countdownEl = document.createElement('div');
                countdownEl.className = 'countdown';
                artistEl.appendChild(countdownEl);
                startCountdown(artistEl, artist.end);
            } else if (isNext) {
                const countdownEl = document.createElement('div');
                countdownEl.className = 'countdown';
                artistEl.appendChild(countdownEl);
                startCountdown(artistEl, artist.start);
            }
            
            artistList.appendChild(artistEl);
        });
        
        stageEl.appendChild(artistList);
        container.appendChild(stageEl);
    }
}

// Initialize when DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    updateTime();
    renderSchedule();
    setInterval(updateTime, 1000);
    // No need for separate renderSchedule interval - countdowns update themselves
});